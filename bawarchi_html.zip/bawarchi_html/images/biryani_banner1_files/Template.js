﻿function codeAddress(address, labeltag, centerLocation) {
    geocoder.geocode({ 'address': address }, function (results, status) {
        if (status == google.maps.GeocoderStatus.OK) {
            alert(results[0].geometry.location);
            if (centerLocation) {
                map.setCenter(results[0].geometry.location);
            }
            var marker0 = new MarkerWithLabel
	        (
		        {
		            position: results[0].geometry.location,
		            draggable: true,
		            animation: google.maps.Animation.DROP,
		            map: map,
		            labelContent: labeltag,
		            labelAnchor: new google.maps.Point(100, 0),
		            labelClass: "label label-success markerlabel",
		            icon: "http://maps.google.com/mapfiles/ms/icons/yellow-dot.png"
		        }
	        );
        } else {
            alert('Geocode was not successful for the following reason: ' + status);
        }
    });
}

function markMap(labeltag) {
    var marker0 = new MarkerWithLabel
	(
		{
		    position: results[0].geometry.location,
		    draggable: true,
		    animation: google.maps.Animation.DROP,
		    map: map,
		    labelContent: labeltag,
		    labelAnchor: new google.maps.Point(100, 0),
		    labelClass: "label label-success markerlabel",
		    icon: "http://maps.google.com/mapfiles/ms/icons/yellow-dot.png"
		}
	);
}